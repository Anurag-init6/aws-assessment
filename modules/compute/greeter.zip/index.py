import boto3, json, uuid, os

def handler(event, context):
    region = os.environ['AWS_REGION']
    dynamo = boto3.client('dynamodb', region_name=region)
    dynamo.put_item(
        TableName='GreetingLogs',
        Item={'id': {'S': str(uuid.uuid4())}, 'region': {'S': region}}
    )
    sns = boto3.client('sns', region_name='us-east-1')
    sns.publish(
        TopicArn='arn:aws:sns:us-east-1:637226132752:Candidate-Verification-Topic',
        Message=json.dumps({
            "email": "singh.anuragsaurabh@gmail.com",
            "source": "Lambda",
            "region": region,
            "repo": "https://github.com/Anurag-ini6/aws-assessment"
        })
    )
    return {'statusCode': 200, 'body': json.dumps({'region': region})}
