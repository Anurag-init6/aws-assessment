import boto3, os, json

def handler(event, context):
    region = os.environ['AWS_REGION']
    ecs = boto3.client('ecs', region_name=region)
    ecs.run_task(
        cluster=os.environ['ECS_CLUSTER'],
        taskDefinition=os.environ['TASK_DEF'],
        launchType='FARGATE',
        networkConfiguration={
            'awsvpcConfiguration': {
                'subnets': [os.environ['SUBNET_ID']],
                'assignPublicIp': 'ENABLED'
            }
        }
    )
    return {'statusCode': 200, 'body': json.dumps({'region': region, 'status': 'task launched'})}
